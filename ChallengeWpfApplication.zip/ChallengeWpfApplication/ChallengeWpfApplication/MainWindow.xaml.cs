﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace ChallengeWpfApplication
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            //TreeView.Items.Refresh();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            //foreach (TreeViewItem dataNode in TreeView.Items)
            for (int i = 0; i < TreeView.Items.Count; i++)
            {
                TreeViewItem dataNode = (TreeViewItem)TreeView.Items[0];
                TraverseChildrenData(dataNode);
            }
        }
        private void TraverseChildrenData(TreeViewItem treeViewItem)
        {
            MessageBox.Show(treeViewItem.Header.ToString());

            foreach (TreeViewItem child in treeViewItem.Items)
            {
                TraverseChildrenData(child);
            }
        }
        

        
    }
}
