﻿using System;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Windows.Media;


namespace ChallengeWpfApplication.ViewModel
{
    public class TreeNode : INotifyPropertyChanged
    {
        //public TreeNode(string Name);
        //public TreeNode(TreeNode node);

        public SolidColorBrush Background { get; set; }
        public int Id { get; set; }
        public string ImageName { get; set; }
        public bool IsExpanded { get; set; }
        public bool canBeDeletedOrAdded { get; set; }
        public bool IsItemsLoaded { get; set; }
        public bool IsSelected { get; set; }
        public string Name { get; set; }
        public TreeNode Parent { get; set; }
        public string ToolTip { get; set; }
        public string ToolTipText { get; set; }
        public string Conditions1 { get; set; }
        public string Conditions2 { get; set; }
        public string Conditions3 { get; set; }
        public decimal? DecValue { get; set; }
        public ObservableCollection<TreeNode> TreeItems { get; set; }

        public event PropertyChangedEventHandler PropertyChanged;
        public TreeNode(string name)
        {
            Name = name;
        }

    }
}
