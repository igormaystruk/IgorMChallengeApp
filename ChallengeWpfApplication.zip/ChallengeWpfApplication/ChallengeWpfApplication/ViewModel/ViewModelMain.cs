﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections.ObjectModel;
using System.Windows;
using System.Xml;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Threading;
using System.ComponentModel;
using GalaSoft.MvvmLight.Command;
using GalaSoft.MvvmLight.Messaging;
using System.Windows.Input;
//using ChallengeWpfApplication.Model;
using ChallengeWpfApplication.Helpers;


namespace ChallengeWpfApplication.ViewModel
{
    public class ViewModelMain : ViewModelBase
    {
        private readonly Dispatcher dispatcher;
        private readonly BackgroundWorker loaderThread;
        private IDataHelperInterface m_controller;

        private RoutedPropertyChangedEventArgs<object> m_e = null;
        private XmlDocument m_doc;
        private bool isCanAdd;
        private string itemName;
        private string itemNewName;
        private string cond1;
        private string cond2;
        private string cond3;
        private bool isConditionExists1;
        private bool isConditionExists2;
        private bool isConditionExists3;
        private string decimalValue;

        public RelayCommandM TestCommand { get; set; }
        public RelayCommandM AddCommand { get; set; }
        public ObservableCollection<TreeNode> TreeList { get; set; }
        public ICommand SelectedItemChangedCommand { get; set; }
        public RelayCommandM UpdateTreeCommand { get; set; }
        public RelayCommandM UpdateCondcommand { get; set; }

        
        public ViewModelMain()
        {


            string s = AppDomain.CurrentDomain.BaseDirectory;
            


            loaderThread = new BackgroundWorker();
            dispatcher = Dispatcher.CurrentDispatcher;
            loaderThread.DoWork += BuildProductionTree;
            m_doc = new XmlDocument();
            m_doc.Load(s + "\\1.xml");
            TreeList = new ObservableCollection<TreeNode>();
            m_controller = new DataHekper(m_doc);
            IsCanAdd = false;
            ItemName = string.Empty;
            ItemNewName = string.Empty;
            Cond1 = string.Empty;
            Cond2 = string.Empty;
            Cond3 = string.Empty;
            DecimalValue = string.Empty;
            InitComamnds();


            loaderThread.RunWorkerAsync();
        }
        #region Public MVVM properties for binding
        public string DecimalValue
        {
            get { return decimalValue; }
            set
            {
                decimalValue = value;
                RaisePropertyChanged("DecimalValue");
            }
        }
        public bool IsConditionExists1
        {
            get { return isConditionExists1; }
            set
            {
                isConditionExists1 = value;
                RaisePropertyChanged("IsConditionExists1");
            }
        }

        public bool IsConditionExists2
        {
            get { return isConditionExists2; }
            set
            {
                isConditionExists2 = value;
                RaisePropertyChanged("IsConditionExists2");
            }
        }

        public bool IsConditionExists3
        {
            get { return isConditionExists3; }
            set
            {
                isConditionExists3 = value;
                RaisePropertyChanged("IsConditionExists3");
            }
        }

        public string Cond1
        {
            get { return cond1; }
            set
            {
                cond1 = value;
                RaisePropertyChanged("Cond1");
            }
        }

        public string Cond2
        {
            get { return cond2; }
            set
            {
                cond2 = value;
                RaisePropertyChanged("Cond2");
            }
        }

        public string Cond3
        {
            get { return cond3; }
            set
            {
                cond3 = value;
                RaisePropertyChanged("Cond3");
            }
        }



        public string ItemNewName
        {
            get { return itemNewName; }
            set
            {
                itemNewName = value;
                RaisePropertyChanged("ItemNewName");
            }
        }
        public string ItemName
        {
            get { return itemName; }
            set
            {
                itemName = value;
                RaisePropertyChanged("ItemName");
            }
        }
        public bool IsCanAdd
        {
            get { return isCanAdd; }
            set
            {
                isCanAdd = value;
                RaisePropertyChanged("IsCanAdd");
            }
        }
        #endregion

        #region private methods
        private void OnTestCommand(object parameter)
        {
            //MessageBox.Show("SSSSSSSSSSS");
            //XmlNodeList l = m_doc.DocumentElement.SelectNodes("NamedDeptors/Item");
            //XmlNodeList l = m_doc.SelectNodes("EDC/Item");
            //foreach(XmlElement elem in l)
            //{
            //    string s = elem.GetAttribute("Name");
            //    MessageBox.Show(s);
            //}



            /*var node = new TreeNode("SSSSSS") { IsExpanded = false, Id = 10 };
            node.TreeItems = new ObservableCollection<TreeNode>();
            

            var node1 = new TreeNode("SSSSSS11") { Parent = node };
            node.TreeItems.Add(node1);


            UpdateTree(node);*/

            //MessageBox.Show(TreeList.Count.ToString());
            //MessageBox.Show(TreeList[0].TreeItems.Count.ToString());

            var item1 = m_e.NewValue as TreeNode;
            foreach (TreeNode item in item1.TreeItems)
            {
                TraverseChildrenData(item);
            }

        }
        /// <summary>
        /// recursive method for update conditions for all childs.
        /// </summary>
        /// <param name="treeViewItem"></param>
        private void TraverseChildrenData(TreeNode treeViewItem)
        {
            if (Cond1 != string.Empty)
            {
                treeViewItem.Conditions1 = Cond1;
            }
            if (Cond2 != string.Empty)
            {
                treeViewItem.Conditions2 = Cond2;
            }
            if (Cond3 != string.Empty)
            {
                treeViewItem.Conditions3 = Cond3;
            }
            if (treeViewItem.TreeItems == null)
            {
                return;
            }
            foreach (TreeNode child in treeViewItem.TreeItems)
            {
                TraverseChildrenData(child);
            }
        }
        private delegate void UpdateDelegate(TreeNode rootnode);
        private void UpdateTree(TreeNode rootNode)
        {
            TreeList.Add(rootNode);
        }
        /// <summary>
        /// Build Tree view from default xml structure, using asynchronic therading (background worker)
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BuildProductionTree(object sender, DoWorkEventArgs e)
        {
            var del = new UpdateDelegate(UpdateTree);
            XmlElement root = m_controller.GetRoot("EDC");
            string name = root.GetAttribute("Name");
            string id = root.GetAttribute("ID");
            var node = new TreeNode(name) {Id = Convert.ToInt32(id), IsExpanded = true, canBeDeletedOrAdded = false, DecValue = null};
            node.TreeItems = new ObservableCollection<TreeNode>();

            XmlElement element1 = m_controller.GetSubRoot(root, "Discretionary");
            name = element1.GetAttribute("Name");
            id = element1.GetAttribute("ID");

            var node1 = new TreeNode(name) { Id = Convert.ToInt32(id), Parent = node, IsExpanded = true, canBeDeletedOrAdded = true, DecValue = null, Conditions1 = string.Empty, Conditions2 = string.Empty, Conditions3 = string.Empty };
            node.TreeItems.Add(node1);

            XmlElement element2 = m_controller.GetSubRoot(root, "NamedDeptors");
            name = element2.GetAttribute("Name");
            id = element2.GetAttribute("ID");

            var node2 = new TreeNode(name) { Id = Convert.ToInt32(id), Parent = node, IsExpanded = true, canBeDeletedOrAdded = true, DecValue = null, Conditions1 = string.Empty, Conditions2 = string.Empty };
            node.TreeItems.Add(node2);

            XmlNodeList items_discr_list = m_controller.GetList(element1, "Item");
            node1.TreeItems = new ObservableCollection<TreeNode>();
            foreach (XmlElement elem in items_discr_list)
            {
                var node_discr = new TreeNode(elem.GetAttribute("Name")) { Id = Convert.ToInt32(elem.GetAttribute("ID")), Parent = node1, canBeDeletedOrAdded = true, DecValue = null, Conditions1 = string.Empty, Conditions2 = string.Empty, Conditions3 = string.Empty };
                node_discr.TreeItems = new ObservableCollection<TreeNode>();
                node1.TreeItems.Add(node_discr);
                XmlNodeList items_discr_list_items = m_controller.GetList(elem, "Item");
                foreach (XmlElement elem_discr in items_discr_list_items)
                {
                    var nodediscr_1 = new TreeNode(elem_discr.GetAttribute("Name")) { Id = Convert.ToInt32(elem_discr.GetAttribute("ID")), Parent = node_discr, canBeDeletedOrAdded = false, DecValue = null, Conditions1 = string.Empty, Conditions2 = string.Empty, Conditions3 = string.Empty };
                    node_discr.TreeItems.Add(nodediscr_1);

                }
            }

            XmlNodeList items_deptors_list = m_controller.GetList(element2, "Item");
            node2.TreeItems = new ObservableCollection<TreeNode>();
            foreach (XmlElement elem in items_deptors_list)
            {
                var node_country = new TreeNode(elem.GetAttribute("Name")) { Id = Convert.ToInt32(elem.GetAttribute("ID")), Parent = node2, canBeDeletedOrAdded = true, DecValue = null, Conditions1 = string.Empty, Conditions2 = string.Empty };
                node_country.TreeItems = new ObservableCollection<TreeNode>();
                node2.TreeItems.Add(node_country);

                XmlNodeList items_deptors_list_deptor = m_controller.GetList(elem, "Item");
                foreach (XmlElement elem_deptor in items_deptors_list_deptor)
                {
                    var node_deptor = new TreeNode(elem_deptor.GetAttribute("Name")) { Id = Convert.ToInt32(elem_deptor.GetAttribute("ID")), Parent = node_country, canBeDeletedOrAdded = false, DecValue = null, Conditions1 = string.Empty, Conditions2 = string.Empty };
                    node_country.TreeItems.Add(node_deptor);
                }
            }

            dispatcher.BeginInvoke(del, DispatcherPriority.DataBind, node); 
        }
        private void SelectedItemChanged(RoutedPropertyChangedEventArgs<object> e)
        {
            var item = (e.NewValue as TreeNode);
            m_e = e;
            IsCanAdd = item.canBeDeletedOrAdded;
            ItemNewName = item.Name;

            if (item.Conditions1 != null)
            {
                Cond1 = item.Conditions1;
                IsConditionExists1 = true;
            }
            else
            {
                IsConditionExists1 = false;
            }
            
            if (item.Conditions2 != null)
            {
                Cond2 = item.Conditions2;
                IsConditionExists2 = true;
            }
            else
            {
                IsConditionExists2 = false;
            }

            if (item.Conditions3 != null)
            {
                Cond3 = item.Conditions1;
                IsConditionExists3 = true;
            }
            else
            {
                IsConditionExists3 = false;
            }

            if (item.DecValue != null)
            {
                DecimalValue = item.DecValue.ToString();
            }
            else
            {
                DecimalValue = string.Empty;
            }

            
        }
        /// <summary>
        /// MVVM relay add node command
        /// </summary>
        /// <param name="parameter"></param>
        private void OnAddCommand(object parameter)
        {
            if (m_e == null)
            {
                return;
            }
            if (ItemName.Trim() == string.Empty)
            {
                MessageBox.Show("Please enter item name");
                return;
            }
            var item_parent = (m_e.NewValue as TreeNode);
                        
            var new_item = new TreeNode(ItemName) { Parent = item_parent, canBeDeletedOrAdded = item_parent.canBeDeletedOrAdded, Conditions1 = item_parent.Conditions1, Conditions2 = item_parent.Conditions2, Conditions3 = item_parent.Conditions3, DecValue = item_parent.DecValue };
            if (item_parent.TreeItems == null)
            {
                item_parent.TreeItems = new ObservableCollection<TreeNode>();
                
            }
            item_parent.TreeItems.Add(new_item);
            ((MainWindow)System.Windows.Application.Current.MainWindow).TreeView.Items.Refresh();
            

        }
        /// <summary>
        /// Relay on update tree command
        /// </summary>
        /// <param name="parameter"></param>
        private void OnUpdateTreeCommand(object parameter)
        {
            if (m_e == null)
            {
                return;
            }
            var item = (m_e.NewValue as TreeNode);
            if (ItemNewName != string.Empty)
            {
                item.Name = ItemNewName;
                
            }
            if (Cond1 != string.Empty)
            {
                item.Conditions1 = Cond1;
            }
            if (Cond2 != string.Empty)
            {
                item.Conditions2 = Cond2;
            }
            if (Cond3 != string.Empty)
            {
                item.Conditions3 = Cond3;
            }



            bool validation_ok = Validation(item);
            if (!validation_ok)
            {
                MessageBox.Show("Decimal Value is Invalid");
                return;
            }
            if (DecimalValue != string.Empty)
            {
                item.DecValue = Convert.ToDecimal(DecimalValue);
            }

            ((MainWindow)System.Windows.Application.Current.MainWindow).TreeView.Items.Refresh();
        }
        /// <summary>
        /// relay on update conditions command
        /// </summary>
        /// <param name="parameter"></param>
        private void OnUpdateCondCommand(object parameter)
        {
            var item1 = m_e.NewValue as TreeNode;
            if (Cond1 != string.Empty)
            {
                item1.Conditions1 = Cond1;
            }
            if (Cond2 != string.Empty)
            {
                item1.Conditions2 = Cond2;
            }
            if (Cond3 != string.Empty)
            {
                item1.Conditions3 = Cond3;
            }
            foreach (TreeNode item in item1.TreeItems)
            {
                TraverseChildrenData(item);
            }
            ((MainWindow)System.Windows.Application.Current.MainWindow).TreeView.Items.Refresh();
        }
        /// <summary>
        /// if conditions configured the decimal value is required.
        /// </summary>
        /// <param name="item"></param>
        /// <returns></returns>
        private bool Validation(TreeNode item)
        {
            if ((item.Conditions1 != null && item.Conditions1 != string.Empty) || (item.Conditions2 != null && item.Conditions2 != string.Empty) || (item.Conditions3 != null && item.Conditions3 != string.Empty))
            {
                if (DecimalValue.Trim() == string.Empty)
                {
                    return false;
                }
                else
                {
                    decimal val;
                    bool b = decimal.TryParse(DecimalValue, out val);
                    if (!b)
                    {
                        return false;
                    }
                }
            }
            return true;
        }
        /// <summary>
        /// Initialization MVVM Relay commands
        /// </summary>
        private void InitComamnds()
        {
            TestCommand = new RelayCommandM(OnTestCommand);
            AddCommand = new RelayCommandM(OnAddCommand);
            UpdateTreeCommand = new RelayCommandM(OnUpdateTreeCommand);
            UpdateCondcommand = new RelayCommandM(OnUpdateCondCommand);
            SelectedItemChangedCommand = new RelayCommand<RoutedPropertyChangedEventArgs<object>>(SelectedItemChanged);
        }
        #endregion
    }
}
